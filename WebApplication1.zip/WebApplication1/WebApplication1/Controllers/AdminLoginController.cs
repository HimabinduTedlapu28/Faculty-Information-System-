﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class AdminLoginController : Controller
    {
        FISEntities db = new FISEntities();
        // GET: AdminLogin
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(Admin a)
        {
            if (ModelState.IsValid == true)
            {
                var credentials = db.Admins.Where(model => model.AdminId == a.AdminId && model.Password == a.Password).FirstOrDefault();
                if (credentials == null)
                {
                    ViewBag.ErrorMessage = "Login Failed";
                    return View();
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }



                //}
                //else
                //{

                //    return RedirectToAction("Index", "Home");
                //}
                
            }
            return View();
        }
    }
}