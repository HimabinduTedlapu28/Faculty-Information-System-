﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;
using System.Net;
using System.Data.Entity;

namespace WebApplication1.Controllers
{
    public class UserLoginController : Controller
    {
        FISEntities db = new FISEntities();
        // GET: UserLogin
        public ActionResult Index()
        {
            return View();
        }
        //public UserType GetById(int UserTypeId)
        //{
        //    var item = db.UserTypes.Find(UserTypeId);
        //    //if(item ==null)
        //    //{
        //    //    return HttpNotFound();
        //    //}
        //    return item;

        //}
        [HttpPost]
        public ActionResult Index(UserType s)
        {
            if (ModelState.IsValid == true)
            {
                var credentials = db.UserTypes.Where(model => model.UserTypeID == s.UserTypeID && model.Password == s.Password && model.username == s.username).FirstOrDefault();
                if (credentials == null)
                {
                    ViewBag.ErrorMessage = "Login Failed";
                    return View();
                }
                else
                {
                    //UserType v =GetById(s.UserTypeID);
                    //SetUserDataInSession(v);

                    Session["UserType"] = s.UserTypeID;
                    Session["username"] = s.username;
                    int a = s.UserTypeID;
                    return RedirectToAction("FacultyDashboard");
                }
                //if(credentials!= null)
                //{
                //    Session["UserType"] = s.UserTypeID;
                //    Session["username"] = s.username;
                //    int a = s.UserTypeID;
                //    return RedirectToAction("FacultyDashboard");
                //}
                


                //}
                //else
                //{

                //    return RedirectToAction("Index", "Home");
                //}

            }
            return View();
        }
        // private void SetUserDataInSession(UserType user)
        // {
        //     // Store user data in session
        //     Session["Id"] = user.UserTypeID;
        //     // Session["Username"] = user.Username;
        // }
        //public UserType GetUserDataFromSession()
        //{
        //    // Retrieve user data from session
        //   // int userId = (int)Session["UserId"];
        //    int UserTypeId = (int)Session["Id"];
        //    //string firstName = (string)Session["FirstName"];
        //    //string lastName = (string)Session["LastName"];
        //    // Retrieve other user properties as needed
        //    // Create a User object and return it
        //    UserType user = new UserType
        //    {
        //        //UserId = userId,
        //        UserTypeID = UserTypeId,
        //        //FirstName = firstName,
        //        //LastName = lastName
        //        // Set other user properties as needed
        //    };
        //    return user;
        //}
        public ActionResult FacultyDashboard()
        {
            // int userid = Session["UserType"];
            //var faculty = db.Faculties.Where(f => f.UserTypeID.Equals(Session["UserType"])).FirstOrDefault();

            if (Session["UserType"] == null)
            {
                return RedirectToAction("Index", "Faculties");
            }

            //return View(db.Faculties.ToList());
            var faculties = db.Faculties.ToList();
            var faculty = faculties.FirstOrDefault(f => f.UserTypeID.Equals(Session["UserType"]));
            if (faculty != null)
            {
                List<Faculty> facultyList = new List<Faculty> { faculty };
                Session["FacultyId"] = faculty.FacultyID;
                Session["Workhistory"] = faculty.FacultyID;
                Session["GrantId"] = faculty.FacultyID;
                Session["CourseTaught"] = faculty.FacultyID;
                return View(facultyList);
            }
            return View();
        }
        public ActionResult WorkHistory()
        {
            int FacultyId = 0;
            if (Session["FacultyId"] == null)
            {
                FacultyId = Convert.ToInt32(Session["FacultyId"]);
                return RedirectToAction("Index", "Home");
            }
            FacultyId = Convert.ToInt32(Session["FacultyId"]);

            //return View(db.Faculties.ToList());
            var workHistories = db.WorkHistories.ToList();
            var WorkHistory = workHistories.FirstOrDefault(f => f.FacultyID.Equals(FacultyId));
            if (WorkHistory != null)
            {
                List<WorkHistory> WorkHistoryList = new List<WorkHistory> { WorkHistory };
                
                return View(WorkHistoryList);
            }
            return View();
        }
        public ActionResult Publication()
        {
            int PubId = 0;
            if (Session["Workhistory"] == null)
            {
                PubId = Convert.ToInt32(Session["Workhistory"]);
                return RedirectToAction("Index", "Home");
            }
            PubId = Convert.ToInt32(Session["Workhistory"]);
            var publication = db.Publications.ToList();
            var Publications = publication.FirstOrDefault(f => f.FacultyID.Equals(PubId));
            if (Publications != null)
            {
                List<Publication> PublicationList = new List<Publication> { Publications };

                return View(PublicationList);
            }
            return View();
        }
        public ActionResult Grant()
        {
            int GrantId = 0;
            if (Session["GrantId"] == null)
            {
                GrantId = Convert.ToInt32(Session["GrantId"]);
                return RedirectToAction("Index", "Home");
            }
            GrantId = Convert.ToInt32(Session["GrantId"]);
            var Grant = db.Grants.ToList();
            var Grants = Grant.FirstOrDefault(f => f.FacultyID.Equals(GrantId));
            if (Grants != null)
            {
                List<Grant> GrantList = new List<Grant> { Grants };

                return View(GrantList);
            }
            return View();
        }
        //public ActionResult HomePage()
        //{
        //    return View();
        //}
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Faculty faculty = db.Faculties.Find(id);
            if (faculty == null)
            {
                return HttpNotFound();
            }
            ViewBag.DeptID = new SelectList(db.Departments, "DeptID", "DeptName", faculty.DeptID);
            ViewBag.DesignationID = new SelectList(db.Designations, "DesignationID", "DesignationName", faculty.DesignationID);
            ViewBag.UserTypeID = new SelectList(db.UserTypes, "UserTypeID", "Password", faculty.UserTypeID);
            return View(faculty);
        }

        // POST: Faculties/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "FacultyID,FirstName,LastName,Address,City,State,Pincode,MobileNo,HireDate,EmailAddress,DateofBirth,DeptID,DesignationID,UserTypeID")] Faculty faculty)
        {
            if (ModelState.IsValid)
            {
                db.Entry(faculty).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.DeptID = new SelectList(db.Departments, "DeptID", "DeptName", faculty.DeptID);
            ViewBag.DesignationID = new SelectList(db.Designations, "DesignationID", "DesignationName", faculty.DesignationID);
            ViewBag.UserTypeID = new SelectList(db.UserTypes, "UserTypeID", "Password", faculty.UserTypeID);
            return View(faculty);
        }
        public ActionResult CourseTaught()
        {
            int Ct = 0;
            if (Session["CourseTaught"] == null)
            {
                Ct = Convert.ToInt32(Session["CourseTaught"]);
                return RedirectToAction("Index", "Home");
            }
            Ct = Convert.ToInt32(Session["CourseTaught"]);
            var CouTau = db.CoursesTaughts.ToList();
            var CouTaug = CouTau.FirstOrDefault(f => f.FacultyID.Equals(Ct));
            if (CouTaug != null)
            {
                List<CoursesTaught> CourseTaughtList = new List<CoursesTaught> { CouTaug };

                return View(CourseTaughtList);
            }
            return View();
        }
    }
    
}